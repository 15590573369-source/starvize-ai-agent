"use client";

import { useState } from "react";
import { MessageSquareText } from "lucide-react";
import { Button, EmptyState, FieldLabel, Panel, SectionTitle, TextArea } from "@/components/Ui";
import { generateReplies } from "@/lib/growth";
import { useGrowthStore } from "@/lib/useGrowthStore";

export default function CommentsPage() {
  const { profile } = useGrowthStore();
  const [comment, setComment] = useState("");
  const [replies, setReplies] = useState<string[]>([]);

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Reply Assistant" title="评论回复助手" />

      <Panel>
        <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-end">
          <FieldLabel label="用户评论">
            <TextArea
              placeholder="粘贴一条用户评论"
              value={comment}
              onChange={(event) => setComment(event.target.value)}
            />
          </FieldLabel>
          <Button onClick={() => setReplies(generateReplies(comment, profile))}>
            <MessageSquareText size={16} />
            生成回复建议
          </Button>
        </div>
      </Panel>

      {replies.length === 0 ? (
        <EmptyState>这里仅生成高质量人工回复建议，不会自动发送评论。</EmptyState>
      ) : (
        <div className="grid gap-4">
          {replies.map((reply, index) => (
            <Panel key={reply}>
              <div className="mb-3 text-xs uppercase tracking-[0.16em] text-gold">
                Reply {index + 1}
              </div>
              <p className="text-sm leading-7 text-stone-100">{reply}</p>
            </Panel>
          ))}
        </div>
      )}
    </div>
  );
}
