import { NextResponse } from "next/server";
import { getProfile, saveProfile } from "@/lib/db";
import { defaultProfile } from "@/lib/growth";
import type { AccountProfile } from "@/lib/types";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json(getProfile() || defaultProfile);
}

export async function PUT(request: Request) {
  const body = (await request.json()) as AccountProfile;
  const next: AccountProfile = {
    accountName: body.accountName || defaultProfile.accountName,
    industry: body.industry || defaultProfile.industry,
    targetFans: body.targetFans || defaultProfile.targetFans,
    businessGoal: body.businessGoal || defaultProfile.businessGoal,
    contentStyle: body.contentStyle || defaultProfile.contentStyle,
    updatedAt: new Date().toISOString()
  };

  return NextResponse.json(saveProfile(next));
}
