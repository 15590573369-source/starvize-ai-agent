import fs from "node:fs";
import path from "node:path";
import type { AccountProfile, CalendarItem, VideoMetric } from "@/lib/types";

type Store = {
  profile?: AccountProfile;
  videos: VideoMetric[];
  calendarItems: CalendarItem[];
};

const dbPath = path.join(process.cwd(), "data", "starvision-store.json");

function ensureStore(): Store {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });

  if (!fs.existsSync(dbPath)) {
    const blank: Store = {
      videos: [],
      calendarItems: []
    };
    fs.writeFileSync(dbPath, JSON.stringify(blank, null, 2), "utf8");
    return blank;
  }

  try {
    const parsed = JSON.parse(fs.readFileSync(dbPath, "utf8")) as Partial<Store>;
    return {
      profile: parsed.profile,
      videos: Array.isArray(parsed.videos) ? parsed.videos : [],
      calendarItems: Array.isArray(parsed.calendarItems) ? parsed.calendarItems : []
    };
  } catch {
    return {
      videos: [],
      calendarItems: []
    };
  }
}

function saveStore(store: Store) {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  fs.writeFileSync(dbPath, JSON.stringify(store, null, 2), "utf8");
}

export function getProfile() {
  return ensureStore().profile;
}

export function saveProfile(profile: AccountProfile) {
  const store = ensureStore();
  store.profile = profile;
  saveStore(store);
  return profile;
}

export function listVideos() {
  return ensureStore().videos.sort((a, b) => {
    const dateSort = b.publishDate.localeCompare(a.publishDate);
    return dateSort || b.id.localeCompare(a.id);
  });
}

export function saveVideo(video: VideoMetric) {
  const store = ensureStore();
  store.videos = [video, ...store.videos.filter((item) => item.id !== video.id)];
  saveStore(store);
  return video;
}

export function removeVideo(id: string) {
  const store = ensureStore();
  store.videos = store.videos.filter((item) => item.id !== id);
  saveStore(store);
}

export function listCalendarItems() {
  return ensureStore().calendarItems.sort((a, b) => a.date.localeCompare(b.date));
}

export function saveCalendarItem(item: CalendarItem) {
  const store = ensureStore();
  store.calendarItems = [
    item,
    ...store.calendarItems.filter((entry) => entry.id !== item.id)
  ].sort((a, b) => a.date.localeCompare(b.date));
  saveStore(store);
  return item;
}

export function removeCalendarItem(id: string) {
  const store = ensureStore();
  store.calendarItems = store.calendarItems.filter((item) => item.id !== id);
  saveStore(store);
}
