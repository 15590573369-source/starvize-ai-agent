"use client";

import { useState } from "react";
import { Wand2 } from "lucide-react";
import { Button, EmptyState, FieldLabel, Panel, SectionTitle, SelectInput, TextArea } from "@/components/Ui";
import { generateScript } from "@/lib/growth";
import { useGrowthStore } from "@/lib/useGrowthStore";
import type { ScriptBlock, ScriptDuration, ScriptFormat } from "@/lib/types";

export default function ScriptsPage() {
  const { profile } = useGrowthStore();
  const [topic, setTopic] = useState("");
  const [duration, setDuration] = useState<ScriptDuration>("30秒");
  const [format, setFormat] = useState<ScriptFormat>("口播稿");
  const [script, setScript] = useState<ScriptBlock[]>([]);

  function buildScript() {
    setScript(generateScript({ topic, duration, format, profile }));
  }

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Script Studio" title="视频脚本生成" />

      <Panel>
        <div className="grid gap-4 lg:grid-cols-[1fr_160px_160px_auto] lg:items-end">
          <FieldLabel label="主题">
            <TextArea
              placeholder="粘贴选题标题，或写下这条视频要解决的问题"
              value={topic}
              onChange={(event) => setTopic(event.target.value)}
              className="min-h-11"
            />
          </FieldLabel>
          <FieldLabel label="时长">
            <SelectInput
              value={duration}
              onChange={(event) => setDuration(event.target.value as ScriptDuration)}
            >
              <option>15秒</option>
              <option>30秒</option>
              <option>60秒</option>
            </SelectInput>
          </FieldLabel>
          <FieldLabel label="类型">
            <SelectInput
              value={format}
              onChange={(event) => setFormat(event.target.value as ScriptFormat)}
            >
              <option>口播稿</option>
              <option>图文脚本</option>
              <option>分镜脚本</option>
            </SelectInput>
          </FieldLabel>
          <Button onClick={buildScript}>
            <Wand2 size={16} />
            生成脚本
          </Button>
        </div>
      </Panel>

      {script.length === 0 ? (
        <EmptyState>选择脚本类型和时长后，生成分段口播、画面建议和执行备注。</EmptyState>
      ) : (
        <div className="grid gap-4">
          {script.map((block) => (
            <Panel key={block.time}>
              <div className="grid gap-4 lg:grid-cols-[120px_1fr_1fr]">
                <div>
                  <div className="text-xs uppercase tracking-[0.16em] text-gold">Time</div>
                  <div className="mt-2 text-xl font-semibold text-[#fff8e8]">{block.time}</div>
                </div>
                <div>
                  <div className="mb-2 text-xs uppercase tracking-[0.14em] text-stone-500">
                    口播/文案
                  </div>
                  <p className="text-sm leading-7 text-stone-100">{block.copy}</p>
                </div>
                <div>
                  <div className="mb-2 text-xs uppercase tracking-[0.14em] text-stone-500">
                    画面建议
                  </div>
                  <p className="text-sm leading-7 text-stone-300">{block.visual}</p>
                  <p className="mt-3 border-t border-white/10 pt-3 text-xs text-gold">
                    {block.note}
                  </p>
                </div>
              </div>
            </Panel>
          ))}
        </div>
      )}
    </div>
  );
}
