"use client";

import { useState } from "react";
import { Captions } from "lucide-react";
import { Button, EmptyState, FieldLabel, Panel, SectionTitle, TextArea } from "@/components/Ui";
import { generateCoverIdeas } from "@/lib/growth";
import { useGrowthStore } from "@/lib/useGrowthStore";
import type { CoverIdea } from "@/lib/types";

export default function CoversPage() {
  const { profile } = useGrowthStore();
  const [topic, setTopic] = useState("");
  const [ideas, setIdeas] = useState<CoverIdea[]>([]);

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Cover Lab" title="封面标题生成" />

      <Panel>
        <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-end">
          <FieldLabel label="视频主题">
            <TextArea
              placeholder="输入视频主题或选题标题"
              value={topic}
              onChange={(event) => setTopic(event.target.value)}
              className="min-h-11"
            />
          </FieldLabel>
          <Button onClick={() => setIdeas(generateCoverIdeas(topic, profile))}>
            <Captions size={16} />
            生成封面
          </Button>
        </div>
      </Panel>

      {ideas.length === 0 ? (
        <EmptyState>生成大标题、副标题和封面视觉建议。</EmptyState>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {ideas.map((idea) => (
            <Panel key={idea.title} className="grid min-h-[260px] content-between">
              <div className="grid-fade mb-6 grid aspect-[4/3] place-items-center rounded-lg border border-gold/20 bg-black/[0.36] p-4 text-center">
                <div>
                  <div className="text-3xl font-black leading-tight text-[#fff2c8]">
                    {idea.title}
                  </div>
                  <div className="mt-3 text-sm text-gold">{idea.subtitle}</div>
                </div>
              </div>
              <div>
                <div className="mb-2 text-xs uppercase tracking-[0.14em] text-stone-500">
                  视觉建议
                </div>
                <p className="text-sm leading-6 text-stone-300">{idea.visual}</p>
              </div>
            </Panel>
          ))}
        </div>
      )}
    </div>
  );
}
