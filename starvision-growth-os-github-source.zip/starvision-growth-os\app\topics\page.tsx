"use client";

import { useMemo, useState } from "react";
import { Sparkles } from "lucide-react";
import { Button, EmptyState, FieldLabel, Panel, SectionTitle, TextInput } from "@/components/Ui";
import { generateTopics } from "@/lib/growth";
import { useGrowthStore } from "@/lib/useGrowthStore";

export default function TopicsPage() {
  const { profile } = useGrowthStore();
  const [keyword, setKeyword] = useState("");
  const [seed, setSeed] = useState("");
  const topics = useMemo(() => (seed ? generateTopics(seed, profile) : []), [seed, profile]);

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Topic Engine" title="爆款选题生成" />

      <Panel>
        <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-end">
          <FieldLabel label="关键词">
            <TextInput
              placeholder="例如：个人品牌、口播、门店获客、知识付费"
              value={keyword}
              onChange={(event) => setKeyword(event.target.value)}
            />
          </FieldLabel>
          <Button onClick={() => setSeed(keyword || profile.industry)}>
            <Sparkles size={16} />
            生成30个选题
          </Button>
        </div>
      </Panel>

      {topics.length === 0 ? (
        <EmptyState>输入关键词后生成标题、3秒钩子、内容结构和结尾关注理由。</EmptyState>
      ) : (
        <div className="grid gap-4">
          {topics.map((topic) => (
            <Panel key={topic.id}>
              <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <div className="mb-2 text-xs uppercase tracking-[0.16em] text-gold">
                    #{String(topic.id).padStart(2, "0")} · {topic.angle}
                  </div>
                  <h2 className="text-lg font-semibold text-[#fff8e8]">{topic.title}</h2>
                </div>
                <span className="w-fit rounded-md border border-white/10 px-3 py-1 text-xs text-stone-400">
                  {profile.industry}
                </span>
              </div>
              <div className="mt-4 grid gap-3 md:grid-cols-3">
                <div className="rounded-lg border border-white/10 bg-black/[0.24] p-4">
                  <div className="mb-2 text-xs text-stone-500">3秒钩子</div>
                  <p className="text-sm leading-6 text-stone-200">{topic.hook}</p>
                </div>
                <div className="rounded-lg border border-white/10 bg-black/[0.24] p-4">
                  <div className="mb-2 text-xs text-stone-500">内容结构</div>
                  <p className="text-sm leading-6 text-stone-200">{topic.structure}</p>
                </div>
                <div className="rounded-lg border border-white/10 bg-black/[0.24] p-4">
                  <div className="mb-2 text-xs text-stone-500">关注理由</div>
                  <p className="text-sm leading-6 text-stone-200">{topic.followReason}</p>
                </div>
              </div>
            </Panel>
          ))}
        </div>
      )}
    </div>
  );
}
