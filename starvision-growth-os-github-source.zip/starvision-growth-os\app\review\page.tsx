"use client";

import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Button, EmptyState, FieldLabel, Panel, SectionTitle, Stat, TextArea, TextInput } from "@/components/Ui";
import { calculateRates, formatPercent, getOptimizationAdvice } from "@/lib/growth";
import { useGrowthStore } from "@/lib/useGrowthStore";
import type { VideoMetric } from "@/lib/types";

function today() {
  return new Date().toISOString().slice(0, 10);
}

function createBlankVideo(): VideoMetric {
  return {
    id: crypto.randomUUID(),
    title: "",
    publishDate: today(),
    topic: "",
    plays: 0,
    likes: 0,
    comments: 0,
    favorites: 0,
    shares: 0,
    newFollowers: 0,
    notes: ""
  };
}

function toNumber(value: string) {
  const next = Number(value);
  return Number.isFinite(next) ? Math.max(0, Math.round(next)) : 0;
}

const numberFormat = new Intl.NumberFormat("zh-CN");

export default function ReviewPage() {
  const { profile, videos, upsertVideo, deleteVideo } = useGrowthStore();
  const [form, setForm] = useState<VideoMetric>(createBlankVideo);
  const advice = getOptimizationAdvice(videos, profile);

  function saveVideo() {
    upsertVideo({
      ...form,
      title: form.title || "未命名视频",
      topic: form.topic || form.title || "未归类选题"
    });
    setForm(createBlankVideo());
  }

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Review" title="数据复盘" />

      <Panel>
        <div className="grid gap-4 lg:grid-cols-3">
          <FieldLabel label="视频标题">
            <TextInput
              value={form.title}
              onChange={(event) => setForm({ ...form, title: event.target.value })}
            />
          </FieldLabel>
          <FieldLabel label="发布时间">
            <TextInput
              type="date"
              value={form.publishDate}
              onChange={(event) => setForm({ ...form, publishDate: event.target.value })}
            />
          </FieldLabel>
          <FieldLabel label="选题方向">
            <TextInput
              value={form.topic}
              onChange={(event) => setForm({ ...form, topic: event.target.value })}
            />
          </FieldLabel>
        </div>

        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-6">
          {[
            ["播放量", "plays"],
            ["点赞", "likes"],
            ["评论", "comments"],
            ["收藏", "favorites"],
            ["转发", "shares"],
            ["新增粉丝", "newFollowers"]
          ].map(([label, key]) => (
            <FieldLabel key={key} label={label}>
              <TextInput
                type="number"
                min={0}
                value={form[key as keyof VideoMetric] as number}
                onChange={(event) =>
                  setForm({
                    ...form,
                    [key]: toNumber(event.target.value)
                  })
                }
              />
            </FieldLabel>
          ))}
        </div>

        <div className="mt-4">
          <FieldLabel label="备注">
            <TextArea
              value={form.notes}
              onChange={(event) => setForm({ ...form, notes: event.target.value })}
              placeholder="记录封面、开头、评论区反馈或你自己的判断"
            />
          </FieldLabel>
        </div>

        <div className="mt-6">
          <Button onClick={saveVideo}>
            <Plus size={16} />
            保存复盘
          </Button>
        </div>
      </Panel>

      <div className="grid gap-4 md:grid-cols-3">
        <Panel>
          <h2 className="mb-3 text-lg font-semibold text-[#fff8e8]">值得继续发</h2>
          <p className="text-sm leading-6 text-stone-300">{advice.keep}</p>
        </Panel>
        <Panel>
          <h2 className="mb-3 text-lg font-semibold text-[#fff8e8]">优化重点</h2>
          <p className="text-sm leading-6 text-stone-300">{advice.improve}</p>
        </Panel>
        <Panel>
          <h2 className="mb-3 text-lg font-semibold text-[#fff8e8]">第二天计划</h2>
          <p className="text-sm leading-6 text-stone-300">{advice.tomorrow}</p>
        </Panel>
      </div>

      {videos.length === 0 ? (
        <EmptyState>录入播放、点赞、评论、收藏、转发和新增粉丝后，系统会自动计算复盘指标。</EmptyState>
      ) : (
        <div className="grid gap-4">
          {videos.map((video) => {
            const rates = calculateRates(video);
            return (
              <Panel key={video.id}>
                <div className="mb-4 flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                  <div>
                    <div className="text-xs uppercase tracking-[0.16em] text-gold">
                      {video.publishDate} · {video.topic}
                    </div>
                    <h2 className="mt-2 text-lg font-semibold text-[#fff8e8]">
                      {video.title}
                    </h2>
                  </div>
                  <Button
                    variant="ghost"
                    className="w-fit px-3"
                    onClick={() => deleteVideo(video.id)}
                    title="删除"
                  >
                    <Trash2 size={15} />
                  </Button>
                </div>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
                  <Stat label="播放" value={numberFormat.format(video.plays)} />
                  <Stat label="点赞率" value={formatPercent(rates.likeRate)} />
                  <Stat label="评论率" value={formatPercent(rates.commentRate)} />
                  <Stat label="收藏率" value={formatPercent(rates.favoriteRate)} />
                  <Stat label="关注转化率" value={formatPercent(rates.followRate)} />
                  <Stat
                    label="涨粉效率"
                    value={
                      rates.followerEfficiency
                        ? `${Math.round(rates.followerEfficiency)} 播/粉`
                        : "暂无"
                    }
                  />
                </div>
                {video.notes ? (
                  <p className="mt-4 border-t border-white/10 pt-4 text-sm leading-6 text-stone-400">
                    {video.notes}
                  </p>
                ) : null}
              </Panel>
            );
          })}
        </div>
      )}
    </div>
  );
}
