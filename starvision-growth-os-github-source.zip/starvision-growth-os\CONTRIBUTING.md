# Contributing

Thanks for considering a contribution.

## Development

```bash
npm install
npm run dev
```

Before submitting changes, run:

```bash
npm run typecheck
npm run build
```

## Compliance Rules

Contributions must preserve the project boundary. Do not add:

- Follower farming, paid followers, protocol followers, or bot followers
- Automatic follow, like, comment, repost, or private-message features
- Simulated login, cookie login, CAPTCHA bypass, or session hijacking
- Proxy pools, device fingerprint spoofing, or multi-account traffic manipulation
- Scraping that violates platform rules or user privacy

Accepted contributions should improve content planning, script generation, manual data review, compliance, UX, or maintainability.
