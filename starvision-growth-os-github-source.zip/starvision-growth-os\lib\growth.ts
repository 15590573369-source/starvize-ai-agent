import type {
  AccountProfile,
  CalendarItem,
  CoverIdea,
  GeneratedTopic,
  ScriptBlock,
  ScriptDuration,
  ScriptFormat,
  VideoMetric
} from "@/lib/types";

export const defaultProfile: AccountProfile = {
  accountName: "造星视界",
  industry: "个人品牌 / 内容增长",
  targetFans: "想通过内容获得信任与成交的创业者、博主、知识型从业者",
  businessGoal: "建立专家信任，沉淀高质量咨询线索",
  contentStyle: "高级、克制、直接、有洞察"
};

const painPoints = [
  "发了很多条却没有记忆点",
  "选题像知识点而不是传播点",
  "账号定位总是说不清",
  "视频开头留不住人",
  "内容有价值但没有转粉理由",
  "数据不错但不知道怎么复盘"
];

const angles = [
  "反常识",
  "误区拆解",
  "清单框架",
  "案例复盘",
  "前后对比",
  "行动模板"
];

const structures = [
  "痛点抛出 -> 原因拆解 -> 解决框架 -> 一句话总结",
  "错误做法 -> 正确做法 -> 示例演示 -> 关注理由",
  "场景代入 -> 关键判断 -> 三步动作 -> 明天可执行",
  "数据现象 -> 内容假设 -> 优化动作 -> 复盘指标",
  "常见问题 -> 底层逻辑 -> 操作清单 -> 评论互动点",
  "目标人群 -> 核心矛盾 -> 内容方法 -> 变现连接"
];

const endings = [
  "关注我，继续拆解可复制的真实增长方法。",
  "收藏这条，下次发视频前直接按这个框架检查。",
  "想要下一版选题清单，可以在评论区留下你的行业。",
  "后面我会继续复盘真实内容数据，适合长期跟着做。",
  "关注后，你会持续拿到更清晰的内容定位和表达模板。",
  "把这条转给团队，下次开选题会可以直接用。"
];

export function generateTopics(
  keyword: string,
  profile: AccountProfile = defaultProfile
): GeneratedTopic[] {
  const base = keyword.trim() || profile.industry || "内容增长";
  const target = profile.targetFans.split(/[，,、]/)[0] || "目标用户";

  return Array.from({ length: 30 }, (_, index) => {
    const pain = painPoints[index % painPoints.length];
    const angle = angles[index % angles.length];
    const titleTemplates = [
      `${base}账号为什么不涨粉？先排查这3个定位问题`,
      `别再只讲干货了，${target}真正想看的是这个`,
      `${base}短视频的3秒开头，可以这样写`,
      `一条视频让用户关注你，关键不是信息量`,
      `${profile.industry}做内容，最容易浪费的5种选题`,
      `把${base}讲清楚：从路人到粉丝的内容结构`
    ];

    return {
      id: index + 1,
      title: titleTemplates[index % titleTemplates.length],
      hook: `如果你的内容${pain}，问题大概率不在勤奋，而在表达顺序。`,
      structure: structures[index % structures.length],
      followReason: endings[index % endings.length],
      angle
    };
  });
}

export function generateScript({
  topic,
  duration,
  format,
  profile
}: {
  topic: string;
  duration: ScriptDuration;
  format: ScriptFormat;
  profile: AccountProfile;
}): ScriptBlock[] {
  const title = topic.trim() || "为什么你的账号有内容却不涨粉";
  const brandTone = profile.contentStyle || "清晰、克制、有洞察";

  const templates: Record<ScriptDuration, ScriptBlock[]> = {
    "15秒": [
      {
        time: "0-3s",
        visual: format === "分镜脚本" ? "正面近景，屏幕左侧出现核心痛点" : "标题页",
        copy: `你的视频不缺信息，缺的是让人立刻在意的理由。`,
        note: "第一句直接点破问题"
      },
      {
        time: "3-11s",
        visual: format === "图文脚本" ? "三张要点卡依次切换" : "手势分层讲解",
        copy: `围绕「${title}」，先说用户正在经历什么，再给一个判断标准，最后给一个今天就能用的动作。`,
        note: `保持${brandTone}，不要堆概念`
      },
      {
        time: "11-15s",
        visual: "金色关键词收束，品牌名淡入",
        copy: `想持续把内容做成资产，关注${profile.accountName || "StarVision"}。`,
        note: "结尾给出明确关注理由"
      }
    ],
    "30秒": [
      {
        time: "0-3s",
        visual: "开场大字：不是你不努力",
        copy: `很多账号不涨粉，不是内容不专业，而是用户看不出和自己有什么关系。`,
        note: "用反差制造停留"
      },
      {
        time: "3-10s",
        visual: "问题拆成三层：人群、场景、收益",
        copy: `讲「${title}」时，先锁定人群，再说具体场景，最后告诉他看完能改变什么。`,
        note: "让抽象选题落到人"
      },
      {
        time: "10-22s",
        visual: format === "分镜脚本" ? "切换到白板/屏幕录制" : "结构卡片",
        copy: `可以用这条公式：我发现一个常见误区，真实原因是A，正确做法是B，今天先改一个动作。`,
        note: "给可复用表达公式"
      },
      {
        time: "22-30s",
        visual: "展示下一条预告标题",
        copy: `下一条我会直接给你一组可套用选题，适合${profile.targetFans || "目标粉丝"}。`,
        note: "自然引导关注"
      }
    ],
    "60秒": [
      {
        time: "0-4s",
        visual: "人物近景，背景保留黑金品牌线条",
        copy: `如果你想靠真实内容涨粉，先别急着追热点，先把「${title}」这件事讲透。`,
        note: "把主题和长期价值绑定"
      },
      {
        time: "4-14s",
        visual: "痛点字幕逐条出现",
        copy: `大多数内容的问题是：标题像内部会议，开头像课程目录，结尾没有关注理由。`,
        note: "用用户能感知的语言"
      },
      {
        time: "14-32s",
        visual: format === "分镜脚本" ? "三段分镜：用户、问题、结果" : "三段式图文页",
        copy: `正确顺序是：先描述目标用户的真实场景，再拆一个关键误区，然后给出一条马上能做的动作。`,
        note: "构建完整内容结构"
      },
      {
        time: "32-48s",
        visual: "案例页：原表达 vs 优化表达",
        copy: `比如不要说「账号定位方法」，而是说「为什么你越垂直越没人记住」。前者像知识点，后者像用户正在经历的问题。`,
        note: "给出具体对比"
      },
      {
        time: "48-60s",
        visual: "收束到品牌和下集预告",
        copy: `把这套结构用在你明天的视频里。关注${profile.accountName || "StarVision"}，我会继续把内容增长拆成能执行的动作。`,
        note: "把关注变成连续收益"
      }
    ]
  };

  return templates[duration];
}

export function generateCoverIdeas(
  topic: string,
  profile: AccountProfile
): CoverIdea[] {
  const base = topic.trim() || `${profile.industry}怎么做真实涨粉`;
  return [
    {
      title: "别再只发干货",
      subtitle: "涨粉靠的是被记住",
      visual: "黑底金字，人物半身靠右，左侧放一条高亮判断线"
    },
    {
      title: "内容不涨粉的真因",
      subtitle: base.slice(0, 22),
      visual: "大标题占画面60%，背景用数据截图弱化处理"
    },
    {
      title: "3秒留人的开头",
      subtitle: "先讲场景，再讲方法",
      visual: "封面中间放倒计时3，边缘加细金线框"
    },
    {
      title: "定位清楚才会转粉",
      subtitle: profile.targetFans.slice(0, 20) || "目标用户要一眼看懂",
      visual: "人物目视镜头，副标题放在下三分之一"
    },
    {
      title: "这类选题继续发",
      subtitle: "用数据筛出增长资产",
      visual: "左侧为折线走势，右侧为核心结论"
    },
    {
      title: "从路人到粉丝",
      subtitle: "一条视频的转化结构",
      visual: "四段箭头：痛点、判断、动作、关注"
    }
  ];
}

export function generateReplies(comment: string, profile: AccountProfile) {
  const clean = comment.trim() || "我也遇到这个问题，应该怎么开始？";
  return [
    `你这个问题很典型。可以先从「目标人群 + 一个具体场景 + 一个可执行动作」开始，不要一上来讲完整体系。`,
    `我理解你的意思，${clean.includes("定位") ? "定位" : "内容"}最好先用一条视频测试反馈，再根据完播、收藏和新增关注来判断是否继续做。`,
    `可以的，我后面会继续拆这个方向。你也可以先把行业和目标用户写下来，我会按${profile.contentStyle || "清晰直接"}的方式给你一个选题思路。`
  ];
}

export function generatePrivateDomainCopy({
  topic,
  profile
}: {
  topic: string;
  profile: AccountProfile;
}) {
  const subject = topic.trim() || `${profile.industry}真实涨粉`;
  return {
    moments: `今天复盘一个很关键的内容增长问题：${subject}。\n\n很多人把短视频当成知识输出，但用户真正会关注你，是因为他看到了持续解决问题的确定性。\n\n如果你也在做账号，可以先检查三件事：标题有没有场景、开头有没有冲突、结尾有没有继续关注的理由。`,
    wechat: `群里同步一个内容选题：${subject}。\n\n适合正在做个人品牌/业务账号的朋友。核心判断：不要只问“这条讲什么”，要问“用户看完为什么愿意下次还看我”。`,
    channels: `${subject}\n\n短视频不是堆信息，而是建立信任路径：痛点被说中、方法能执行、账号值得持续关注。`,
    xiaohongshu: `我发现很多账号不涨粉，不是因为不专业，而是表达顺序错了。\n\n围绕「${subject}」，建议用：真实场景 -> 常见误区 -> 一个动作 -> 关注理由。\n\n这样内容既有价值，也更容易被收藏和转粉。`
  };
}

export function calculateRates(video: VideoMetric) {
  const plays = Math.max(video.plays, 0);
  const safeDivide = (value: number) => (plays > 0 ? value / plays : 0);

  return {
    likeRate: safeDivide(video.likes),
    commentRate: safeDivide(video.comments),
    favoriteRate: safeDivide(video.favorites),
    shareRate: safeDivide(video.shares),
    followRate: safeDivide(video.newFollowers),
    followerEfficiency:
      video.newFollowers > 0 ? plays / Math.max(video.newFollowers, 1) : 0
  };
}

export function formatPercent(value: number) {
  return `${(value * 100).toFixed(value >= 0.1 ? 1 : 2)}%`;
}

export function summarizeVideos(videos: VideoMetric[]) {
  const totals = videos.reduce(
    (acc, video) => {
      acc.plays += video.plays;
      acc.likes += video.likes;
      acc.comments += video.comments;
      acc.favorites += video.favorites;
      acc.shares += video.shares;
      acc.newFollowers += video.newFollowers;
      return acc;
    },
    {
      plays: 0,
      likes: 0,
      comments: 0,
      favorites: 0,
      shares: 0,
      newFollowers: 0
    }
  );

  return {
    ...totals,
    avgFollowRate:
      totals.plays > 0 ? totals.newFollowers / Math.max(totals.plays, 1) : 0,
    avgFavoriteRate:
      totals.plays > 0 ? totals.favorites / Math.max(totals.plays, 1) : 0
  };
}

export function getOptimizationAdvice(videos: VideoMetric[], profile: AccountProfile) {
  if (videos.length === 0) {
    return {
      keep: "先录入最近3-5条视频数据，优先观察收藏率和关注转化率。",
      improve: "下一条内容建议使用“痛点场景 + 误区拆解 + 一个动作”的结构。",
      tomorrow: `围绕${profile.industry || "核心领域"}做一条30秒口播，标题直接指向目标用户正在经历的问题。`
    };
  }

  const sorted = [...videos].sort((a, b) => {
    const aScore =
      calculateRates(a).favoriteRate * 0.35 +
      calculateRates(a).followRate * 0.45 +
      calculateRates(a).commentRate * 0.2;
    const bScore =
      calculateRates(b).favoriteRate * 0.35 +
      calculateRates(b).followRate * 0.45 +
      calculateRates(b).commentRate * 0.2;
    return bScore - aScore;
  });

  const best = sorted[0];
  const rates = calculateRates(best);
  const signal =
    rates.followRate >= 0.01
      ? "关注转化强"
      : rates.favoriteRate >= 0.03
        ? "收藏意图强"
        : rates.commentRate >= 0.005
          ? "讨论意愿强"
          : "基础反馈稳定";

  return {
    keep: `继续放大「${best.topic || best.title}」方向，当前最强信号是${signal}。`,
    improve:
      rates.favoriteRate < 0.02
        ? "加强可收藏结构：清单、模板、判断标准、步骤图。"
        : "保留当前结构，下一条换一个更具体的人群场景测试。",
    tomorrow: `明天发一条围绕「${best.topic || best.title}」的延展内容：开头复用高反馈痛点，中段给一个新案例，结尾预告下一条复盘。`
  };
}

export function createStarterCalendar(): CalendarItem[] {
  const today = new Date();
  return ["选题", "脚本", "拍摄", "剪辑", "发布"].map((stage, index) => {
    const date = new Date(today);
    date.setDate(today.getDate() + index);
    return {
      id: crypto.randomUUID(),
      title: `真实涨粉内容计划 ${index + 1}`,
      date: date.toISOString().slice(0, 10),
      stage: stage as CalendarItem["stage"],
      channel: "抖音",
      status: index === 0 ? "进行中" : "待处理"
    };
  });
}
