export type AccountProfile = {
  accountName: string;
  industry: string;
  targetFans: string;
  businessGoal: string;
  contentStyle: string;
  updatedAt?: string;
};

export type GeneratedTopic = {
  id: number;
  title: string;
  hook: string;
  structure: string;
  followReason: string;
  angle: string;
};

export type ScriptFormat = "口播稿" | "图文脚本" | "分镜脚本";
export type ScriptDuration = "15秒" | "30秒" | "60秒";

export type ScriptBlock = {
  time: string;
  visual: string;
  copy: string;
  note: string;
};

export type CoverIdea = {
  title: string;
  subtitle: string;
  visual: string;
};

export type VideoMetric = {
  id: string;
  title: string;
  publishDate: string;
  topic: string;
  plays: number;
  likes: number;
  comments: number;
  favorites: number;
  shares: number;
  newFollowers: number;
  notes: string;
};

export type CalendarStage = "选题" | "脚本" | "拍摄" | "剪辑" | "发布";
export type CalendarStatus = "待处理" | "进行中" | "已完成";

export type CalendarItem = {
  id: string;
  title: string;
  date: string;
  stage: CalendarStage;
  channel: string;
  status: CalendarStatus;
};
