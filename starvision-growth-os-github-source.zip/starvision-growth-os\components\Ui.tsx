import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";

export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

export function Panel({
  children,
  className = ""
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <section
      className={cn(
        "rounded-lg border border-white/10 bg-panel/[0.88] p-5 shadow-panel backdrop-blur",
        className
      )}
    >
      {children}
    </section>
  );
}

export function SectionTitle({
  eyebrow,
  title,
  action
}: {
  eyebrow?: string;
  title: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow ? (
          <p className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-gold">
            {eyebrow}
          </p>
        ) : null}
        <h1 className="text-2xl font-semibold text-[#fff8e8] sm:text-3xl">
          {title}
        </h1>
      </div>
      {action}
    </div>
  );
}

export function FieldLabel({
  label,
  children
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="grid gap-2 text-sm text-stone-300">
      <span className="text-xs font-medium uppercase tracking-[0.14em] text-stone-500">
        {label}
      </span>
      {children}
    </label>
  );
}

export function TextInput(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={cn(
        "min-h-11 rounded-md border border-white/10 bg-black/35 px-3 text-sm text-stone-100 outline-none transition focus:border-gold/70 focus:ring-2 focus:ring-gold/15",
        props.className
      )}
    />
  );
}

export function TextArea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={cn(
        "min-h-28 rounded-md border border-white/10 bg-black/35 px-3 py-3 text-sm text-stone-100 outline-none transition focus:border-gold/70 focus:ring-2 focus:ring-gold/15",
        props.className
      )}
    />
  );
}

export function SelectInput(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={cn(
        "min-h-11 rounded-md border border-white/10 bg-black/70 px-3 text-sm text-stone-100 outline-none transition focus:border-gold/70 focus:ring-2 focus:ring-gold/15",
        props.className
      )}
    />
  );
}

export function Button({
  variant = "primary",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger";
}) {
  const variants = {
    primary:
      "border-gold/50 bg-gold text-black hover:bg-ember hover:border-ember",
    secondary:
      "border-white/[0.12] bg-white/[0.07] text-stone-100 hover:border-gold/50 hover:text-gold",
    ghost:
      "border-transparent bg-transparent text-stone-300 hover:bg-white/[0.06] hover:text-gold",
    danger:
      "border-red-400/30 bg-red-500/10 text-red-100 hover:bg-red-500/[0.18]"
  };

  return (
    <button
      {...props}
      className={cn(
        "inline-flex min-h-10 items-center justify-center gap-2 rounded-md border px-4 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-45",
        variants[variant],
        className
      )}
    />
  );
}

export function Stat({
  label,
  value,
  hint
}: {
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <div className="rounded-lg border border-white/10 bg-black/[0.24] p-4">
      <div className="text-xs uppercase tracking-[0.14em] text-stone-500">
        {label}
      </div>
      <div className="mt-2 text-2xl font-semibold text-[#fff7df]">{value}</div>
      {hint ? <div className="mt-2 text-xs text-stone-500">{hint}</div> : null}
    </div>
  );
}

export function EmptyState({ children }: { children: ReactNode }) {
  return (
    <div className="rounded-lg border border-dashed border-white/[0.14] bg-black/20 p-6 text-sm leading-6 text-stone-400">
      {children}
    </div>
  );
}
