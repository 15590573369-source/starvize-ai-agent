"use client";

import { useState } from "react";
import { Share2 } from "lucide-react";
import { Button, EmptyState, FieldLabel, Panel, SectionTitle, TextArea } from "@/components/Ui";
import { generatePrivateDomainCopy } from "@/lib/growth";
import { useGrowthStore } from "@/lib/useGrowthStore";

export default function PrivateDomainPage() {
  const { profile } = useGrowthStore();
  const [topic, setTopic] = useState("");
  const [copy, setCopy] = useState<ReturnType<typeof generatePrivateDomainCopy> | null>(null);

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Private Domain" title="私域同步文案生成" />

      <Panel>
        <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-end">
          <FieldLabel label="同步主题">
            <TextArea
              value={topic}
              onChange={(event) => setTopic(event.target.value)}
              placeholder="输入今天发布的视频主题或复盘结论"
            />
          </FieldLabel>
          <Button onClick={() => setCopy(generatePrivateDomainCopy({ topic, profile }))}>
            <Share2 size={16} />
            生成文案
          </Button>
        </div>
      </Panel>

      {!copy ? (
        <EmptyState>生成朋友圈、微信群、视频号和小红书文案，人工复制后发布。</EmptyState>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {[
            ["朋友圈", copy.moments],
            ["微信群", copy.wechat],
            ["视频号", copy.channels],
            ["小红书", copy.xiaohongshu]
          ].map(([label, value]) => (
            <Panel key={label}>
              <div className="mb-3 text-xs uppercase tracking-[0.16em] text-gold">
                {label}
              </div>
              <p className="whitespace-pre-line text-sm leading-7 text-stone-100">{value}</p>
            </Panel>
          ))}
        </div>
      )}
    </div>
  );
}
