"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  CalendarDays,
  Captions,
  ClipboardPenLine,
  FileText,
  Home,
  MessageSquareText,
  PenLine,
  Settings2,
  Share2,
  ShieldCheck,
  Sparkles
} from "lucide-react";
import { cn } from "@/components/Ui";

const navItems = [
  { href: "/", label: "数据看板", icon: Home },
  { href: "/positioning", label: "账号定位", icon: Settings2 },
  { href: "/topics", label: "爆款选题", icon: Sparkles },
  { href: "/scripts", label: "视频脚本", icon: FileText },
  { href: "/covers", label: "封面标题", icon: Captions },
  { href: "/comments", label: "评论助手", icon: MessageSquareText },
  { href: "/calendar", label: "排期日历", icon: CalendarDays },
  { href: "/review", label: "数据复盘", icon: BarChart3 },
  { href: "/private-domain", label: "私域同步", icon: Share2 }
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-72 border-r border-white/10 bg-[#070707]/90 px-4 py-5 backdrop-blur-xl lg:block">
        <Link href="/" className="mb-7 flex items-center gap-3 rounded-lg px-2">
          <div className="grid h-11 w-11 place-items-center rounded-lg border border-gold/45 bg-gold/10 text-gold shadow-gold">
            <PenLine size={20} />
          </div>
          <div>
            <div className="text-base font-semibold text-[#fff7df]">
              StarVision
            </div>
            <div className="text-xs uppercase tracking-[0.24em] text-stone-500">
              Growth OS
            </div>
          </div>
        </Link>

        <nav className="grid gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-md border px-3 py-3 text-sm transition",
                  isActive
                    ? "border-gold/35 bg-gold/[0.12] text-gold"
                    : "border-transparent text-stone-400 hover:border-white/10 hover:bg-white/[0.05] hover:text-stone-100"
                )}
              >
                <Icon size={17} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="absolute bottom-5 left-4 right-4 rounded-lg border border-mint/20 bg-mint/[0.07] p-4 text-xs leading-5 text-stone-300">
          <div className="mb-2 flex items-center gap-2 font-semibold text-mint">
            <ShieldCheck size={15} />
            合规模式
          </div>
          仅生成内容建议、复盘洞察和人工回复参考；不提供自动互动、登录绕过、群控或刷量能力。
        </div>
      </aside>

      <header className="sticky top-0 z-30 border-b border-white/10 bg-[#070707]/92 px-4 py-3 backdrop-blur lg:hidden">
        <div className="mb-3 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-md border border-gold/45 bg-gold/10 text-gold">
              <PenLine size={17} />
            </div>
            <div>
              <div className="text-sm font-semibold text-[#fff7df]">StarVision</div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-stone-500">
                Growth OS
              </div>
            </div>
          </Link>
          <div className="flex items-center gap-2 rounded-md border border-mint/20 bg-mint/[0.07] px-3 py-2 text-xs text-mint">
            <ShieldCheck size={14} />
            合规
          </div>
        </div>
        <nav className="flex gap-2 overflow-x-auto pb-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "inline-flex shrink-0 items-center gap-2 rounded-md border px-3 py-2 text-xs transition",
                  isActive
                    ? "border-gold/35 bg-gold/[0.12] text-gold"
                    : "border-white/10 text-stone-400"
                )}
              >
                <Icon size={14} />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </header>

      <main className="lg:pl-72">
        <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
          {children}
        </div>
      </main>
    </div>
  );
}
