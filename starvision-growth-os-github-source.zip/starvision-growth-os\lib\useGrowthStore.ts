"use client";

import { useCallback, useEffect, useState } from "react";
import { createStarterCalendar, defaultProfile } from "@/lib/growth";
import type { AccountProfile, CalendarItem, VideoMetric } from "@/lib/types";

const profileKey = "starvision.profile";
const videosKey = "starvision.videos";
const calendarKey = "starvision.calendar";

function readLocal<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const value = window.localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeLocal<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

async function apiJson<T>(url: string, options?: RequestInit) {
  const res = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options?.headers || {})
    }
  });

  if (!res.ok) throw new Error(`Request failed: ${url}`);
  return (await res.json()) as T;
}

export function useGrowthStore() {
  const [profile, setProfileState] = useState<AccountProfile>(defaultProfile);
  const [videos, setVideos] = useState<VideoMetric[]>([]);
  const [calendar, setCalendar] = useState<CalendarItem[]>([]);
  const [isReady, setReady] = useState(false);

  useEffect(() => {
    let isMounted = true;

    async function load() {
      const localProfile = readLocal(profileKey, defaultProfile);
      const localVideos = readLocal<VideoMetric[]>(videosKey, []);
      const localCalendar = readLocal<CalendarItem[]>(calendarKey, createStarterCalendar());

      setProfileState(localProfile);
      setVideos(localVideos);
      setCalendar(localCalendar);

      try {
        const [remoteProfile, remoteVideos, remoteCalendar] = await Promise.all([
          apiJson<AccountProfile>("/api/profile"),
          apiJson<VideoMetric[]>("/api/videos"),
          apiJson<CalendarItem[]>("/api/calendar-items")
        ]);

        if (!isMounted) return;
        setProfileState(remoteProfile);
        setVideos(remoteVideos);
        setCalendar(remoteCalendar.length > 0 ? remoteCalendar : localCalendar);
        writeLocal(profileKey, remoteProfile);
        writeLocal(videosKey, remoteVideos);
        writeLocal(calendarKey, remoteCalendar.length > 0 ? remoteCalendar : localCalendar);
      } catch {
        // Local fallback keeps the tool usable even before SQLite dependencies finish installing.
      } finally {
        if (isMounted) setReady(true);
      }
    }

    load();
    return () => {
      isMounted = false;
    };
  }, []);

  const saveProfile = useCallback(async (next: AccountProfile) => {
    const withDate = { ...next, updatedAt: new Date().toISOString() };
    setProfileState(withDate);
    writeLocal(profileKey, withDate);
    try {
      await apiJson<AccountProfile>("/api/profile", {
        method: "PUT",
        body: JSON.stringify(withDate)
      });
    } catch {
      // Local fallback has already saved the update.
    }
  }, []);

  const upsertVideo = useCallback(async (video: VideoMetric) => {
    setVideos((current) => {
      const next = [video, ...current.filter((item) => item.id !== video.id)];
      writeLocal(videosKey, next);
      return next;
    });
    try {
      await apiJson<VideoMetric>("/api/videos", {
        method: "POST",
        body: JSON.stringify(video)
      });
    } catch {
      // Local fallback has already saved the update.
    }
  }, []);

  const deleteVideo = useCallback(async (id: string) => {
    setVideos((current) => {
      const next = current.filter((item) => item.id !== id);
      writeLocal(videosKey, next);
      return next;
    });
    try {
      await apiJson<{ ok: boolean }>(`/api/videos?id=${encodeURIComponent(id)}`, {
        method: "DELETE"
      });
    } catch {
      // Local fallback has already saved the update.
    }
  }, []);

  const upsertCalendarItem = useCallback(async (item: CalendarItem) => {
    setCalendar((current) => {
      const next = [item, ...current.filter((entry) => entry.id !== item.id)].sort((a, b) =>
        a.date.localeCompare(b.date)
      );
      writeLocal(calendarKey, next);
      return next;
    });
    try {
      await apiJson<CalendarItem>("/api/calendar-items", {
        method: "POST",
        body: JSON.stringify(item)
      });
    } catch {
      // Local fallback has already saved the update.
    }
  }, []);

  const deleteCalendarItem = useCallback(async (id: string) => {
    setCalendar((current) => {
      const next = current.filter((item) => item.id !== id);
      writeLocal(calendarKey, next);
      return next;
    });
    try {
      await apiJson<{ ok: boolean }>(`/api/calendar-items?id=${encodeURIComponent(id)}`, {
        method: "DELETE"
      });
    } catch {
      // Local fallback has already saved the update.
    }
  }, []);

  return {
    isReady,
    profile,
    videos,
    calendar,
    saveProfile,
    upsertVideo,
    deleteVideo,
    upsertCalendarItem,
    deleteCalendarItem
  };
}
