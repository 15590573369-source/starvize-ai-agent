"use client";

import { useState } from "react";
import { CalendarPlus, Trash2 } from "lucide-react";
import { Button, EmptyState, FieldLabel, Panel, SectionTitle, SelectInput, TextInput } from "@/components/Ui";
import { createStarterCalendar } from "@/lib/growth";
import { useGrowthStore } from "@/lib/useGrowthStore";
import type { CalendarItem, CalendarStage, CalendarStatus } from "@/lib/types";

function today() {
  return new Date().toISOString().slice(0, 10);
}

const blankItem = (): CalendarItem => ({
  id: crypto.randomUUID(),
  title: "",
  date: today(),
  stage: "选题",
  channel: "抖音",
  status: "待处理"
});

export default function CalendarPage() {
  const { calendar, upsertCalendarItem, deleteCalendarItem } = useGrowthStore();
  const [form, setForm] = useState<CalendarItem>(blankItem);

  function addItem() {
    upsertCalendarItem({
      ...form,
      title: form.title || "未命名内容"
    });
    setForm(blankItem());
  }

  function addStarterPlan() {
    createStarterCalendar().forEach((item) => upsertCalendarItem(item));
  }

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Calendar" title="内容排期日历" />

      <Panel>
        <div className="grid gap-4 lg:grid-cols-[1fr_150px_140px_140px_140px_auto] lg:items-end">
          <FieldLabel label="内容标题">
            <TextInput
              value={form.title}
              onChange={(event) => setForm({ ...form, title: event.target.value })}
            />
          </FieldLabel>
          <FieldLabel label="日期">
            <TextInput
              type="date"
              value={form.date}
              onChange={(event) => setForm({ ...form, date: event.target.value })}
            />
          </FieldLabel>
          <FieldLabel label="阶段">
            <SelectInput
              value={form.stage}
              onChange={(event) =>
                setForm({ ...form, stage: event.target.value as CalendarStage })
              }
            >
              <option>选题</option>
              <option>脚本</option>
              <option>拍摄</option>
              <option>剪辑</option>
              <option>发布</option>
            </SelectInput>
          </FieldLabel>
          <FieldLabel label="渠道">
            <SelectInput
              value={form.channel}
              onChange={(event) => setForm({ ...form, channel: event.target.value })}
            >
              <option>抖音</option>
              <option>视频号</option>
              <option>小红书</option>
              <option>私域</option>
            </SelectInput>
          </FieldLabel>
          <FieldLabel label="状态">
            <SelectInput
              value={form.status}
              onChange={(event) =>
                setForm({ ...form, status: event.target.value as CalendarStatus })
              }
            >
              <option>待处理</option>
              <option>进行中</option>
              <option>已完成</option>
            </SelectInput>
          </FieldLabel>
          <Button onClick={addItem}>
            <CalendarPlus size={16} />
            添加
          </Button>
        </div>
        <div className="mt-4">
          <Button variant="secondary" onClick={addStarterPlan}>
            生成5天节奏
          </Button>
        </div>
      </Panel>

      {calendar.length === 0 ? (
        <EmptyState>添加内容后，排期会按日期排序。</EmptyState>
      ) : (
        <div className="grid gap-4">
          {calendar.map((item) => (
            <Panel key={item.id}>
              <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="text-xs uppercase tracking-[0.16em] text-gold">
                    {item.date} · {item.channel}
                  </div>
                  <h2 className="mt-2 text-lg font-semibold text-[#fff8e8]">{item.title}</h2>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-md border border-white/10 px-3 py-2 text-xs text-stone-300">
                    {item.stage}
                  </span>
                  <SelectInput
                    value={item.status}
                    onChange={(event) =>
                      upsertCalendarItem({
                        ...item,
                        status: event.target.value as CalendarStatus
                      })
                    }
                    className="min-h-9"
                  >
                    <option>待处理</option>
                    <option>进行中</option>
                    <option>已完成</option>
                  </SelectInput>
                  <Button
                    variant="ghost"
                    className="min-h-9 px-3"
                    onClick={() => deleteCalendarItem(item.id)}
                    title="删除"
                  >
                    <Trash2 size={15} />
                  </Button>
                </div>
              </div>
            </Panel>
          ))}
        </div>
      )}
    </div>
  );
}
