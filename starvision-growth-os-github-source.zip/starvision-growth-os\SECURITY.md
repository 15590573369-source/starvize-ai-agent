# Security Policy

## Supported Versions

The current `main` branch is supported.

## Reporting a Vulnerability

Please open a GitHub issue with clear reproduction steps and impact. Do not include private tokens, cookies, account credentials, or personal data.

## Project Boundary

Security reports related to prohibited automation, platform bypass, credential harvesting, or traffic manipulation will not be treated as feature requests. Those capabilities are outside the scope of this project.
