import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        carbon: "#070707",
        ink: "#0d0d0d",
        panel: "#12110f",
        gold: "#d7b56d",
        ember: "#ffcf70",
        mint: "#83f3c4"
      },
      boxShadow: {
        gold: "0 24px 80px rgba(215, 181, 109, 0.12)",
        panel: "0 18px 60px rgba(0, 0, 0, 0.28)"
      },
      fontFamily: {
        sans: [
          "Inter",
          "ui-sans-serif",
          "system-ui",
          "Segoe UI",
          "Arial",
          "sans-serif"
        ]
      }
    }
  },
  plugins: []
};

export default config;
