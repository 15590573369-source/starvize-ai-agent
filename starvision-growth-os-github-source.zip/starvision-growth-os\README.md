# StarVision Growth OS

StarVision Growth OS is a compliant content growth workspace for short-video creators. It focuses on planning, scripting, cover copy, manual data review, comment reply suggestions, content scheduling, and private-domain copy generation.

This project does not include follower farming, paid followers, bot followers, automatic follows, automatic likes, automatic comments, batch private messages, simulated login, cookie login, CAPTCHA bypass, device fingerprint spoofing, proxy pools, or traffic manipulation.

## Features

- Dashboard for account and content performance
- Account positioning settings
- 30-topic short-video idea generator
- 15s, 30s, and 60s script generator
- Spoken script, graphic script, and storyboard modes
- Cover headline and visual suggestion generator
- Manual data review with calculated engagement rates
- Comment reply assistant for manual replies only
- Content scheduling calendar
- Private-domain copy generator for Moments, WeChat groups, Channels, and Xiaohongshu

## Tech Stack

- Next.js
- React
- Tailwind CSS
- Local JSON file persistence

## Getting Started

Install dependencies:

```bash
npm install
```

Run the development server:

```bash
npm run dev
```

Open:

```text
http://localhost:3000
```

Build for production:

```bash
npm run build
```

Start the production server:

```bash
npm run start
```

## Data Storage

Runtime data is saved locally in:

```text
data/starvision-store.json
```

This file is ignored by Git to avoid publishing private operating data.

## Compliance Boundary

StarVision Growth OS only provides content strategy, copywriting, review, and planning assistance. It is designed for real audience growth through content quality and manual decision-making.

Do not add features that automate platform interactions or bypass platform protections.

## License

MIT
