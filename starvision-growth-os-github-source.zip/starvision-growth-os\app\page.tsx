"use client";

import Link from "next/link";
import { ArrowRight, BarChart3, CalendarDays, CheckCircle2, Sparkles, TrendingUp } from "lucide-react";
import { Button, EmptyState, Panel, SectionTitle, Stat } from "@/components/Ui";
import { calculateRates, formatPercent, getOptimizationAdvice, summarizeVideos } from "@/lib/growth";
import { useGrowthStore } from "@/lib/useGrowthStore";

const numberFormat = new Intl.NumberFormat("zh-CN");

export default function DashboardPage() {
  const { profile, videos, calendar } = useGrowthStore();
  const summary = summarizeVideos(videos);
  const advice = getOptimizationAdvice(videos, profile);
  const best = [...videos].sort(
    (a, b) => calculateRates(b).followRate - calculateRates(a).followRate
  )[0];
  const nextItems = calendar
    .filter((item) => item.status !== "已完成")
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <SectionTitle
        eyebrow="StarVision Growth OS"
        title="真实涨粉内容中枢"
        action={
          <Link href="/topics">
            <Button>
              <Sparkles size={16} />
              生成选题
            </Button>
          </Link>
        }
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Stat label="累计播放" value={numberFormat.format(summary.plays)} hint="手动录入数据" />
        <Stat label="新增粉丝" value={numberFormat.format(summary.newFollowers)} hint="真实转化" />
        <Stat label="平均关注率" value={formatPercent(summary.avgFollowRate)} hint="新增粉丝 / 播放" />
        <Stat label="平均收藏率" value={formatPercent(summary.avgFavoriteRate)} hint="收藏 / 播放" />
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.1fr_0.9fr]">
        <Panel className="overflow-hidden">
          <div className="mb-5 flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gold">
                Account Position
              </p>
              <h2 className="mt-2 text-xl font-semibold text-[#fff8e8]">
                {profile.accountName}
              </h2>
            </div>
            <Link href="/positioning">
              <Button variant="secondary">
                调整定位
                <ArrowRight size={15} />
              </Button>
            </Link>
          </div>

          <div className="grid gap-3 text-sm text-stone-300 md:grid-cols-2">
            <div className="rounded-lg border border-white/10 bg-black/[0.24] p-4">
              <div className="mb-2 text-xs uppercase tracking-[0.14em] text-stone-500">
                行业领域
              </div>
              {profile.industry}
            </div>
            <div className="rounded-lg border border-white/10 bg-black/[0.24] p-4">
              <div className="mb-2 text-xs uppercase tracking-[0.14em] text-stone-500">
                商业目标
              </div>
              {profile.businessGoal}
            </div>
            <div className="rounded-lg border border-white/10 bg-black/[0.24] p-4 md:col-span-2">
              <div className="mb-2 text-xs uppercase tracking-[0.14em] text-stone-500">
                目标粉丝
              </div>
              {profile.targetFans}
            </div>
          </div>
        </Panel>

        <Panel>
          <div className="mb-4 flex items-center gap-2 text-gold">
            <TrendingUp size={18} />
            <h2 className="text-lg font-semibold text-[#fff8e8]">内容优化建议</h2>
          </div>
          <div className="space-y-3 text-sm leading-6 text-stone-300">
            <p>{advice.keep}</p>
            <p>{advice.improve}</p>
            <p className="border-t border-white/10 pt-3 text-[#fff0c8]">
              {advice.tomorrow}
            </p>
          </div>
        </Panel>
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        <Panel>
          <div className="mb-4 flex items-center gap-2">
            <BarChart3 className="text-gold" size={18} />
            <h2 className="text-lg font-semibold text-[#fff8e8]">高转粉视频</h2>
          </div>
          {best ? (
            <div className="space-y-4">
              <div>
                <div className="text-xl font-semibold text-[#fff8e8]">{best.title}</div>
                <div className="mt-2 text-sm text-stone-500">{best.publishDate}</div>
              </div>
              <div className="grid gap-3 sm:grid-cols-3">
                <Stat label="播放" value={numberFormat.format(best.plays)} />
                <Stat label="关注率" value={formatPercent(calculateRates(best).followRate)} />
                <Stat label="单条涨粉" value={numberFormat.format(best.newFollowers)} />
              </div>
            </div>
          ) : (
            <EmptyState>录入视频数据后，这里会显示最值得延展的内容方向。</EmptyState>
          )}
        </Panel>

        <Panel>
          <div className="mb-4 flex items-center gap-2">
            <CalendarDays className="text-gold" size={18} />
            <h2 className="text-lg font-semibold text-[#fff8e8]">近期排期</h2>
          </div>
          {nextItems.length > 0 ? (
            <div className="space-y-3">
              {nextItems.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between gap-4 rounded-lg border border-white/10 bg-black/[0.24] p-3"
                >
                  <div>
                    <div className="font-medium text-stone-100">{item.title}</div>
                    <div className="mt-1 text-xs text-stone-500">
                      {item.date} · {item.stage} · {item.channel}
                    </div>
                  </div>
                  <span className="shrink-0 rounded-md border border-gold/25 px-2 py-1 text-xs text-gold">
                    {item.status}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <EmptyState>安排下一批内容后，会在这里形成发布节奏。</EmptyState>
          )}
        </Panel>
      </div>

      <Panel className="border-mint/20 bg-mint/[0.07]">
        <div className="flex flex-col gap-3 text-sm text-stone-300 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2 font-semibold text-mint">
            <CheckCircle2 size={17} />
            合规增长边界已启用
          </div>
          <span>
            系统只做内容策划、脚本、封面、人工回复建议、复盘和同步文案。
          </span>
        </div>
      </Panel>
    </div>
  );
}
