import { NextResponse } from "next/server";
import { listVideos, removeVideo, saveVideo } from "@/lib/db";
import type { VideoMetric } from "@/lib/types";

export const runtime = "nodejs";

function toInt(value: unknown) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, Math.round(number)) : 0;
}

function normalize(body: Partial<VideoMetric>): VideoMetric {
  return {
    id: body.id || crypto.randomUUID(),
    title: body.title || "未命名视频",
    publishDate: body.publishDate || new Date().toISOString().slice(0, 10),
    topic: body.topic || "",
    plays: toInt(body.plays),
    likes: toInt(body.likes),
    comments: toInt(body.comments),
    favorites: toInt(body.favorites),
    shares: toInt(body.shares),
    newFollowers: toInt(body.newFollowers),
    notes: body.notes || ""
  };
}

export async function GET() {
  return NextResponse.json(listVideos());
}

export async function POST(request: Request) {
  const video = normalize((await request.json()) as Partial<VideoMetric>);
  return NextResponse.json(saveVideo(video));
}

export async function DELETE(request: Request) {
  const id = new URL(request.url).searchParams.get("id");
  if (!id) {
    return NextResponse.json({ ok: false }, { status: 400 });
  }

  removeVideo(id);
  return NextResponse.json({ ok: true });
}
