import { NextResponse } from "next/server";
import { listCalendarItems, removeCalendarItem, saveCalendarItem } from "@/lib/db";
import type { CalendarItem, CalendarStage, CalendarStatus } from "@/lib/types";

export const runtime = "nodejs";

const stages: CalendarStage[] = ["选题", "脚本", "拍摄", "剪辑", "发布"];
const statuses: CalendarStatus[] = ["待处理", "进行中", "已完成"];

function normalize(body: Partial<CalendarItem>): CalendarItem {
  return {
    id: body.id || crypto.randomUUID(),
    title: body.title || "未命名内容",
    date: body.date || new Date().toISOString().slice(0, 10),
    stage: stages.includes(body.stage as CalendarStage)
      ? (body.stage as CalendarStage)
      : "选题",
    channel: body.channel || "抖音",
    status: statuses.includes(body.status as CalendarStatus)
      ? (body.status as CalendarStatus)
      : "待处理"
  };
}

export async function GET() {
  return NextResponse.json(listCalendarItems());
}

export async function POST(request: Request) {
  const item = normalize((await request.json()) as Partial<CalendarItem>);
  return NextResponse.json(saveCalendarItem(item));
}

export async function DELETE(request: Request) {
  const id = new URL(request.url).searchParams.get("id");
  if (!id) {
    return NextResponse.json({ ok: false }, { status: 400 });
  }

  removeCalendarItem(id);
  return NextResponse.json({ ok: true });
}
