"use client";

import { useEffect, useState } from "react";
import { Save } from "lucide-react";
import { Button, FieldLabel, Panel, SectionTitle, TextArea, TextInput } from "@/components/Ui";
import { useGrowthStore } from "@/lib/useGrowthStore";
import type { AccountProfile } from "@/lib/types";

export default function PositioningPage() {
  const { profile, saveProfile } = useGrowthStore();
  const [form, setForm] = useState<AccountProfile>(profile);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setForm(profile);
  }, [profile]);

  async function handleSave() {
    await saveProfile(form);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 1800);
  }

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Positioning" title="账号定位设置" />

      <Panel>
        <div className="grid gap-5 lg:grid-cols-2">
          <FieldLabel label="账号名称">
            <TextInput
              value={form.accountName}
              onChange={(event) => setForm({ ...form, accountName: event.target.value })}
            />
          </FieldLabel>
          <FieldLabel label="行业领域">
            <TextInput
              value={form.industry}
              onChange={(event) => setForm({ ...form, industry: event.target.value })}
            />
          </FieldLabel>
          <FieldLabel label="目标粉丝">
            <TextArea
              value={form.targetFans}
              onChange={(event) => setForm({ ...form, targetFans: event.target.value })}
            />
          </FieldLabel>
          <FieldLabel label="商业目标">
            <TextArea
              value={form.businessGoal}
              onChange={(event) => setForm({ ...form, businessGoal: event.target.value })}
            />
          </FieldLabel>
          <FieldLabel label="内容风格">
            <TextArea
              value={form.contentStyle}
              onChange={(event) => setForm({ ...form, contentStyle: event.target.value })}
              className="lg:col-span-2"
            />
          </FieldLabel>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-3">
          <Button onClick={handleSave}>
            <Save size={16} />
            保存定位
          </Button>
          {saved ? <span className="text-sm text-mint">已保存</span> : null}
        </div>
      </Panel>
    </div>
  );
}
